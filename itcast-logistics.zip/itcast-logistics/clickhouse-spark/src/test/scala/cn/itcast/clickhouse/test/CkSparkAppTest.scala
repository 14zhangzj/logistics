package cn.itcast.clickhouse.test

object CkSparkAppTest {
	def main(args: Array[String]): Unit = {
		println("Hello World。。。。。。。。。。。。。。。。。。。。。。。")
	}
}
