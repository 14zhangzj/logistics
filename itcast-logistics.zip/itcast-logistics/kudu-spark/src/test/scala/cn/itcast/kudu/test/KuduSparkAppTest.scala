package cn.itcast.kudu.test

object KuduSparkAppTest {
	
	def main(args: Array[String]): Unit = {
		println("Hello World.............")
	}
	
}
