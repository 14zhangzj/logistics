package cn.itcast.logistics.test

object AppTest {
	
	def main(args: Array[String]): Unit = {
		println("Hello World...........")
	}
	
}
